<?php
// Template placeholder for Snow plugin.
?><div class="wrap"><h1>Snow Plugin</h1><p>This is a placeholder template for the Snow plugin.</p></div>
