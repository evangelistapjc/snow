<?php
/**
 * Ingestion handler for Intapp Snow.
 *
 * This class renders the CSV upload form and processes uploaded files.  CSV
 * files should include the following columns: `team_member`, `metric_name`,
 * `metric_value`, `metric_date`, `ab_test`.  Rows are associated with
 * marketer posts and aggregated into simple metric caches.  Both the raw
 * uploaded rows and the per‑marketer aggregates are stored as options for
 * downstream consumption by the dashboard and scoring engine.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Intapp_Snow_Ingest {
    /**
     * Render the ingestion upload form.  Provides a file input and optional
     * marketer selector to associate the upload with a specific marketer.  If
     * no marketer is selected, the upload is treated as organisational data.
     */
    public static function render() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $nonce     = wp_create_nonce( 'intapp_snow_ingest' );
        $marketers = get_posts( array( 'post_type' => 'intapp_marketer', 'numberposts' => -1 ) );
        ?>
        <div class="wrap snow-wrap"><h1>Intapp Snow Ingest</h1>
            <form method="post" enctype="multipart/form-data" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
                <input type="hidden" name="action" value="intapp_snow_ingest_upload" />
                <input type="hidden" name="_wpnonce" value="<?php echo esc_attr( $nonce ); ?>" />
                <p><input type="file" name="intapp_snow_file" required /></p>
                <p>Attach to marketer: <select name="marketer_id"><option value="">— Optional —</option>
                        <?php foreach ( $marketers as $m ) {
                            echo '<option value="' . esc_attr( $m->ID ) . '">' . esc_html( get_the_title( $m ) ) . '</option>';
                        } ?>
                    </select></p>
                <p><button class="button button-primary">Upload &amp; Parse</button></p>
            </form>
        </div>
        <?php
    }

    /**
     * Handles the file upload and updates caches.  On success the user is
     * redirected back to the ingest page with a success flag.
     */
    public static function handle_upload() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }
        check_admin_referer( 'intapp_snow_ingest' );
        if ( empty( $_FILES['intapp_snow_file']['tmp_name'] ) ) {
            wp_die( 'No file uploaded' );
        }
        $tmp  = $_FILES['intapp_snow_file']['tmp_name'];
        $name = $_FILES['intapp_snow_file']['name'];
        $ext  = strtolower( pathinfo( $name, PATHINFO_EXTENSION ) );
        $data = array();
        if ( $ext === 'csv' || $ext === 'tsv' ) {
            $sep = ( $ext === 'tsv' ) ? "\t" : ',';
            $fh  = fopen( $tmp, 'r' );
            if ( ! $fh ) {
                wp_die( 'Failed to open uploaded file' );
            }
            $hdr = fgetcsv( $fh, 0, $sep );
            if ( ! is_array( $hdr ) ) {
                $hdr = array();
            }
            $rows = array();
            while ( ( $row = fgetcsv( $fh, 0, $sep ) ) !== false ) {
                if ( count( $row ) === count( $hdr ) ) {
                    $rows[] = array_combine( $hdr, $row );
                }
            }
            fclose( $fh );
            $data = $rows;
        } elseif ( $ext === 'json' ) {
            $raw  = file_get_contents( $tmp );
            $data = json_decode( $raw, true );
            if ( ! is_array( $data ) ) {
                $data = array();
            }
        } else {
            // For unknown formats store raw contents as string
            $data = array( 'raw' => file_get_contents( $tmp ) );
        }
        // Determine marketer association.  If provided, we update only that marketer's
        // cache.  Otherwise store organisation‑level data.
        $marketer_id = isset( $_POST['marketer_id'] ) ? intval( $_POST['marketer_id'] ) : 0;
        if ( $marketer_id ) {
            $aggregated = array();
            foreach ( $data as $row ) {
                if ( ! is_array( $row ) ) {
                    continue;
                }
                // Normalise keys to lower case to avoid mismatches
                $row = array_change_key_case( $row, CASE_LOWER );
                $mname  = isset( $row['team_member'] ) ? trim( $row['team_member'] ) : '';
                $mkey   = sanitize_title( $mname );
                $metric = isset( $row['metric_name'] ) ? sanitize_key( $row['metric_name'] ) : '';
                $value  = isset( $row['metric_value'] ) ? floatval( $row['metric_value'] ) : null;
                if ( $metric && $value !== null ) {
                    // Use last value per metric for simplicity.  You could accumulate or
                    // average here depending on your use case.
                    $aggregated[ $metric ] = $value;
                }
            }
            update_option( 'snow_marketer_cache_' . $marketer_id, array( 'uploaded_at' => time(), 'file' => $name, 'data' => $aggregated ), false );
        } else {
            // Store as organisation upload
            update_option( 'snow_upload_cache_org', array( 'uploaded_at' => time(), 'file' => $name, 'data' => $data ), false );
        }
        wp_safe_redirect( admin_url( 'admin.php?page=intapp-snow-ingest&ok=1' ) );
        exit;
    }
}