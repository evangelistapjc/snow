<?php
/**
 * Sample data seeder for Intapp Snow.
 *
 * Seeds a handful of marketers, teams and KPIs for demonstration purposes.  This
 * is invoked on plugin activation so you can immediately see the dashboard
 * populated with example content.  Feel free to remove or modify these seeds to
 * match your organisation.  Note that seeding is idempotent — existing posts
 * will not be duplicated.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Peej_Snow_SampleData {
    public static function seed() {
        // Seed a simplified set of teams for the personal plugin.  Use a distinct
        // taxonomy to avoid clashes with the primary Intapp Snow plugin.
        $teams = array( 'Personal Growth', 'Professional Growth', 'Health & Wellbeing' );
        foreach ( $teams as $team ) {
            if ( ! term_exists( $team, 'peej_team' ) ) {
                wp_insert_term( $team, 'peej_team' );
            }
        }

        // Create a single marketer profile for Peej.  If it already exists, skip.
        $name = 'Peej';
        $team = 'Personal Growth';
        $title = $name . ' (' . $team . ')';
        $existing = get_page_by_title( $title, OBJECT, 'peej_marketer' );
        if ( ! $existing ) {
            $id = wp_insert_post( array(
                'post_type'    => 'peej_marketer',
                'post_title'   => $title,
                'post_status'  => 'publish',
                'post_content' => '[Auto‑generated marketer profile for personal codex]',
            ) );
            if ( $id && ! is_wp_error( $id ) ) {
                wp_set_post_terms( $id, array( $team ), 'peej_team' );
                // Seed baseline KPIs and goals based off the Future‑Proof Peej codex
                update_post_meta( $id, 'snow_kpis', 'Experiment Velocity, Sitewide CVR, Wins Log Frequency' );
                update_post_meta( $id, 'snow_goals', 'Double experiment velocity; improve conversion; daily wins log' );
            }
        }

        // Create a default campaign if one does not exist.  This campaign uses
        // baseline and projected KPIs inspired by the Future‑Proof Peej playbook.
        $campaign_title = 'Future Proof Peej';
        $existing_campaign = get_page_by_title( $campaign_title, OBJECT, 'peej_campaign' );
        if ( ! $existing_campaign ) {
            $cid = wp_insert_post( array(
                'post_type'    => 'peej_campaign',
                'post_title'   => $campaign_title,
                'post_status'  => 'publish',
                'post_content' => 'Self‑directed growth campaign based on the Future‑Proof Peej codex.',
            ) );
            if ( $cid && ! is_wp_error( $cid ) ) {
                // Baselines represent the current state
                $baseline_kpis   = array( 'Experiment Velocity: 2 tests/mo', 'Sitewide CVR: 3%', 'Wins Log Frequency: 40%' );
                $projection_kpis = array( 'Experiment Velocity: 4 tests/mo', 'Sitewide CVR: 5%', 'Wins Log Frequency: 80%' );
                update_post_meta( $cid, 'kpi_baselines', $baseline_kpis );
                update_post_meta( $cid, 'kpi_projections', $projection_kpis );
                update_post_meta( $cid, 'impact', 'This campaign aims to fuse technical rigour with human connection, accelerate testing velocity and improve overall site performance.' );
                update_post_meta( $cid, 'business_case', 'By doubling the pace of high‑ROI experiments and elevating conversion rates, we anticipate material revenue lift and a stronger personal brand.' );
                update_post_meta( $cid, 'future_holdings', 'The codex will evolve into a public framework for technical + human synergy across the organisation.' );
            }
        }
    }
}