=== Intapp Snow (CRO/A‑B Ops Framework) ===
Contributors: peej
Tags: cro, ab testing, marketing ops, kpi, integrations, wordpress
Requires at least: 5.8
Tested up to: 6.x
Stable tag: 0.6.0
License: GPLv2
Text Domain: intapp-snow

== Description ==
**Unified CRO and marketing operations framework for WordPress**

Intapp Snow is a plugin built from the ground up to support experimentation and growth within marketing teams.  It unifies per‑marketer dashboards, A/B test management, KPI tracking and third‑party integrations into a single cohesive experience.  The plugin is designed to work both internally and externally — enabling you to sanitise data for public consumption while still leveraging the full power of the framework behind the scenes.  It requires no external dependencies and operates even if Advanced Custom Fields (ACF) is disabled.

* Per‑marketer dashboards with KPIs, goals and AI‑generated experiment suggestions
* A/B test management with scoring, owner assignment and dependency tracking
* CSV ingest utility for uploading metrics and associating them with marketers
* Optional sample data seeding on activation
* HubSpot integration out of the box (private app token), ready for further integrations
* Asana‑friendly CSV export of experiments

== Installation ==
1. Upload the `intapp-snow` folder to your `/wp-content/plugins/` directory or install the zip via the WordPress plugin uploader.
2. Activate the plugin through the Plugins menu.
3. On first activation, sample marketers and teams are seeded automatically.  You can remove or edit them as desired.
4. Visit **Intapp Snow → Settings** to choose operating mode (internal/external).
5. Optional: Go to **Intapp Snow → Integrations** to enable HubSpot or future integrations.
6. Optional: Go to **Intapp Snow → Ingest** to upload a CSV of metrics.  The CSV must include `team_member`, `metric_name`, `metric_value`, `metric_date` and `ab_test` columns.

== Frequently Asked Questions ==

*Why do you use custom post types instead of users?*  Marketers are stored as posts so that you can separate organisational structure from WordPress user roles.  You can link a marketer to a user via post meta if desired.

*Do I need ACF Pro?*  No.  The plugin stores data in standard post meta.  If ACF Pro is active you can expose fields in the post editor, but it is not required.

*Can I integrate with tools other than HubSpot?*  Yes.  Integrations are modular.  You can drop new integration classes into `includes/integrations` and register them in `class-intapp-snow-integrations.php`.

== Screenshots ==
1. Intapp Snow dashboard showing marketers and top suggestions.
2. HubSpot snapshot and ingestion page.
3. A/B tests and dependencies lists.

== Changelog ==
= 0.6.0 =
* Added “Campaigns” post type for self‑automated initiatives led by senior dev/optimisation leads.  Campaigns store KPI baselines, projections, business impact narratives and link to a WordPress user.
* Included custom meta box for campaigns with owner selector and text areas.
* Added campaigns listing table and sub‑menu.

= 0.5.0 =
* Initial release of Intapp Snow.  Forked from Snow prototype v0.4.1 and enhanced with CSV ingest, user linking and modular integrations.

== Privacy ==
The plugin stores only aggregate metrics and does not expose personally identifiable information.  External API calls are opt‑in and read‑only.  Always review your organisation's privacy policies before enabling integrations.