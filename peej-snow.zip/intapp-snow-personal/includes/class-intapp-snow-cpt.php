<?php
/**
 * Custom post types and taxonomies for the Intapp Snow plugin.
 *
 * This class encapsulates registration for the various content objects used by the
 * framework.  Marketers represent individuals in your Marketing Ops or growth team;
 * Metrics allow fine‑grained tracking of KPI values over time; A/B Tests represent
 * experimental ideas with associated scores; Dependencies capture pre‑requisites
 * required to launch a test; and Teams group marketers for aggregation.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Peej_Snow_CPT {

    /**
     * Register all custom post types and taxonomies.  Hooked into init.
     */
    public static function register() {
        // Marketer profiles (similar to authors but decoupled from WP user roles).  A marketer
        // can optionally be linked to a WP user via post meta.  We disable front‑end
        // visibility but keep the UI in the dashboard.
        // Personal marketer profiles.  We use a distinct post type slug to avoid
        // colliding with the primary Intapp Snow plugin.  Each post can be linked
        // to a WP user and stores KPIs/goals via post meta.
        register_post_type( 'peej_marketer', array(
            'label'               => __( 'Marketers', 'intapp-snow' ),
            'labels'              => array(
                'singular_name' => __( 'Marketer', 'intapp-snow' ),
                'add_new_item'  => __( 'Add New Marketer', 'intapp-snow' ),
                'edit_item'     => __( 'Edit Marketer', 'intapp-snow' ),
                'new_item'      => __( 'New Marketer', 'intapp-snow' ),
                'not_found'     => __( 'No marketers found', 'intapp-snow' )
            ),
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => false,
            'supports'            => array( 'title', 'editor' ),
            'capability_type'     => 'post'
        ) );

        // Experimental A/B tests.  Tests are created either manually or programmatically
        // based off scoring suggestions.  Each test is assigned to a marketer via meta.
        // Personal experimental A/B tests.
        register_post_type( 'peej_abtest', array(
            'label'        => __( 'A/B Tests', 'intapp-snow' ),
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => false,
            'supports'     => array( 'title', 'editor' ),
            'capability_type' => 'post'
        ) );

        // Dependencies or prerequisites for tests.  These may correspond to assets, reviews
        // or third‑party approvals.
        // Personal dependencies/prerequisites for tests.
        register_post_type( 'peej_dependency', array(
            'label'        => __( 'Dependencies', 'intapp-snow' ),
            'public'       => false,
            'show_ui'      => true,
            'show_in_menu' => false,
            'supports'     => array( 'title', 'editor' ),
            'capability_type' => 'post'
        ) );

        // Metrics log.  Each metric record is stored as a post so that it can be queried
        // easily and joined across marketers, teams and tests.  We intentionally avoid
        // exposing this post type in the admin menu; metrics are surfaced through
        // dedicated dashboard views instead.
        // Personal metrics log.
        register_post_type( 'peej_metric', array(
            'label'        => __( 'Metrics', 'intapp-snow' ),
            'public'       => false,
            'show_ui'      => false,
            'supports'     => array( 'title' )
        ) );

        // Campaigns.  Campaigns represent self‑contained optimisation initiatives
        // orchestrated by a senior developer or optimisation lead.  Each campaign
        // can be linked to a WordPress user (owner) and carries baseline and
        // projected KPIs as well as a business case.  The custom fields meta box
        // is registered separately in the admin class.  We expose campaigns in
        // the UI via a dedicated sub‑menu.
        // Personal campaigns.  Campaigns encapsulate optimisation initiatives for Peej.
        register_post_type( 'peej_campaign', array(
            'label'               => __( 'Campaigns', 'intapp-snow' ),
            'labels'              => array(
                'singular_name' => __( 'Campaign', 'intapp-snow' ),
                'add_new_item'  => __( 'Add New Campaign', 'intapp-snow' ),
                'edit_item'     => __( 'Edit Campaign', 'intapp-snow' ),
                'new_item'      => __( 'New Campaign', 'intapp-snow' ),
                'not_found'     => __( 'No campaigns found', 'intapp-snow' )
            ),
            'public'              => false,
            'show_ui'             => true,
            'show_in_menu'        => false,
            'supports'            => array( 'title', 'editor', 'author' ),
            'capability_type'     => 'post'
        ) );

        // Team taxonomy to group marketers.  Use hierarchical to support nested teams.
        // Personal team taxonomy used to group marketers.  Uses hierarchical to allow
        // nested teams.
        register_taxonomy( 'peej_team', array( 'peej_marketer' ), array(
            'label'        => __( 'Teams', 'intapp-snow' ),
            'public'       => false,
            'show_ui'      => true,
            'hierarchical' => true,
        ) );
    }
}