<?php
/**
 * Scoring engine for Intapp Snow.
 *
 * Provides heuristics for suggesting A/B tests based on available metrics.  This
 * implementation mirrors the Snow v0.4 scoring algorithm.  You can extend or
 * replace the heuristics to suit your organisation's specific KPIs and
 * experimentation cadence.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Intapp_Snow_Scorer {
    const OPTION_WEIGHTS = 'snow_scoring_weights';

    /**
     * Retrieve the weighting factors used for scoring.  Stored in an option but
     * defaults can be overridden by the admin via code or future UI.
     *
     * @return array Associative array of weight names to floats.
     */
    public static function get_weights() {
        $defaults = array(
            'conversion_impact'    => 0.35,
            'traffic_volume'       => 0.20,
            'effort_inverse'       => 0.15,
            'dependency_readiness' => 0.10,
            'kpi_alignment'        => 0.15,
            'recency'              => 0.05,
        );
        return wp_parse_args( get_option( self::OPTION_WEIGHTS, array() ), $defaults );
    }

    /**
     * Generate a list of suggested experiments for a marketer.  The heuristics
     * look at specific metric keys to infer pain points and opportunities.
     * Suggestions are sorted by descending score.
     *
     * @param int   $marketer_id Marketer post ID.
     * @param array $metrics     Key/value array of metrics.
     * @return array List of suggestion arrays.
     */
    public static function suggest_for_marketer( $marketer_id, $metrics ) {
        $ideas = array();
        $kpis  = strtolower( (string) get_post_meta( $marketer_id, 'snow_kpis', true ) );
        $w     = self::get_weights();
        // Heuristic 1: form friction
        if ( ! empty( $metrics['forms_count'] ) && isset( $metrics['form_drop_rate'] ) ) {
            $score  = self::score(
                $w,
                min( 1, max( 0, floatval( $metrics['form_drop_rate'] ) ) ),
                min( 1, self::norm( $metrics, 'form_views', 100, 5000 ) ),
                0.8,
                self::dep_ready( $metrics, array( 'analytics_form_submit', 'privacy_ok' ) ),
                ( strpos( $kpis, 'cvr' ) !== false || strpos( $kpis, 'cpl' ) !== false ) ? 1 : 0.6,
                0.8
            );
            $ideas[] = array(
                'title'      => 'Paid LP – Short (3f) vs Long (6f) Form',
                'hypothesis' => 'Reducing required fields increases completions with acceptable lead quality.',
                'method'     => 'A/B: 3 vs 6 fields; QA CDA mapping; privacy review.',
                'kpis'       => array( 'Form CVR', 'CPL', 'Lead Quality Score', 'Pipeline' ),
                'deps'       => array( 'CDA mapping', 'Privacy/legal review', 'Analytics QA' ),
                'score'      => $score,
                'reason'     => 'High drop‑off + traffic; aligns to CVR/CPL; low effort.',
            );
        }
        // Heuristic 2: persona messaging
        if ( ! empty( $metrics['persona_sources'] ) && isset( $metrics['reg_cvr'] ) ) {
            $score  = self::score(
                $w,
                ( floatval( $metrics['reg_cvr'] ) < 0.08 ) ? 0.7 : 0.4,
                min( 1, self::norm( $metrics, 'sessions', 500, 20000 ) ),
                0.6,
                self::dep_ready( $metrics, array( 'copy_approved', 'optimizely_project' ) ),
                ( strpos( $kpis, 'cvr' ) !== false ) ? 1 : 0.7,
                0.9
            );
            $ideas[] = array(
                'title'      => 'Amplify Persona Targeting – Legal vs PE',
                'hypothesis' => 'Persona‑aligned value props lift registrations.',
                'method'     => 'Optimizely variants by source persona; shared CTA.',
                'kpis'       => array( 'Registration CVR', 'CTR', 'Bounce', 'Time on Page' ),
                'deps'       => array( 'Copy approvals', 'Persona assets', 'Analytics events' ),
                'score'      => $score,
                'reason'     => 'Persona traffic present; CVR below benchmark.',
            );
        }
        // Heuristic 3: video capture
        if ( ! empty( $metrics['wistia_plays'] ) && isset( $metrics['turnstile_cvr'] ) ) {
            $score  = self::score(
                $w,
                ( floatval( $metrics['turnstile_cvr'] ) < 0.03 ) ? 0.75 : 0.4,
                min( 1, self::norm( $metrics, 'wistia_plays', 200, 20000 ) ),
                0.9,
                self::dep_ready( $metrics, array( 'wistia_access' ) ),
                ( strpos( $kpis, 'leads' ) !== false || strpos( $kpis, 'cvr' ) !== false ) ? 0.9 : 0.6,
                0.7
            );
            $ideas[] = array(
                'title'      => 'Wistia – Mid‑roll Turnstile vs End‑screen',
                'hypothesis' => 'Mid‑roll increases leads/play.',
                'method'     => 'Randomize timing; same asset.',
                'kpis'       => array( 'Turnstile CVR', 'Leads/Play', 'Assisted Pipeline' ),
                'deps'       => array( 'Wistia project access', 'Embed swap QA' ),
                'score'      => $score,
                'reason'     => 'High plays with low capture.',
            );
        }
        // Heuristic 4: email CTA position
        if ( ! empty( $metrics['email_sends'] ) && isset( $metrics['email_ctor'] ) ) {
            $score  = self::score(
                $w,
                ( floatval( $metrics['email_ctor'] ) < 0.12 ) ? 0.6 : 0.35,
                min( 1, self::norm( $metrics, 'email_sends', 1000, 200000 ) ),
                0.8,
                self::dep_ready( $metrics, array( 'email_template_access' ) ),
                ( strpos( $kpis, 'ctr' ) !== false || strpos( $kpis, 'cvr' ) !== false ) ? 0.9 : 0.6,
                0.8
            );
            $ideas[] = array(
                'title'      => 'Email – Top vs Bottom CTA',
                'hypothesis' => 'Above‑the‑fold CTA increases CTR & downstream CVR.',
                'method'     => 'Two templates; identical audience.',
                'kpis'       => array( 'CTR', 'CTOR', 'Downstream CVR' ),
                'deps'       => array( 'Template editing', 'QA', 'Seed list' ),
                'score'      => $score,
                'reason'     => 'Large sends with middling CTOR.',
            );
        }
        // Heuristic 5: performance optimisation sprint
        if ( isset( $metrics['lcp_ms'] ) ) {
            $score  = self::score(
                $w,
                ( floatval( $metrics['lcp_ms'] ) > 3000 ) ? 0.7 : 0.3,
                min( 1, self::norm( $metrics, 'sessions', 500, 20000 ) ),
                0.5,
                self::dep_ready( $metrics, array( 'perf_budget', 'image_assets' ) ),
                ( strpos( $kpis, 'cvr' ) !== false || strpos( $kpis, 'bounce' ) !== false ) ? 0.8 : 0.5,
                0.6
            );
            $ideas[] = array(
                'title'      => 'Perf Sprint – Image Optimization vs Baseline',
                'hypothesis' => 'Reducing LCP improves engagement and conversion.',
                'method'     => 'Optimize hero media; track LCP/Bounce/CVR.',
                'kpis'       => array( 'LCP', 'Bounce', 'CVR' ),
                'deps'       => array( 'Design assets', 'Perf budget', 'Analytics' ),
                'score'      => $score,
                'reason'     => 'Slow LCP detected; broad upside.',
            );
        }
        usort( $ideas, function( $a, $b ) {
            return ( $a['score'] < $b['score'] ) ? 1 : -1;
        } );
        return $ideas;
    }

    /**
     * Helper to compute a weighted score.  Takes the weight array and six
     * dimension values (each 0–1) corresponding to the factors defined in
     * get_weights().
     */
    private static function score( $w, $impact, $traffic, $effortInv, $deps, $kpi, $rec ) {
        return round( 100 * ( $w['conversion_impact'] * $impact + $w['traffic_volume'] * $traffic + $w['effort_inverse'] * $effortInv + $w['dependency_readiness'] * $deps + $w['kpi_alignment'] * $kpi + $w['recency'] * $rec ) );
    }

    /**
     * Normalise a metric between a minimum and maximum.  Values below the
     * minimum return 0; above the maximum return 1; otherwise scaled linearly.
     */
    private static function norm( $m, $key, $min, $max ) {
        $v = isset( $m[ $key ] ) ? floatval( $m[ $key ] ) : 0;
        if ( $v <= $min ) {
            return 0.0;
        }
        if ( $v >= $max ) {
            return 1.0;
        }
        return ( $v - $min ) / ( $max - $min );
    }

    /**
     * Determine dependency readiness as the proportion of required dependencies
     * present in the metrics.  A value of 1 means all dependencies are present.
     */
    private static function dep_ready( $metrics, $needed ) {
        $ok = 0;
        $n  = count( $needed );
        foreach ( $needed as $k ) {
            if ( ! empty( $metrics[ 'dep_' . $k ] ) ) {
                $ok++;
            }
        }
        return $n ? $ok / $n : 1.0;
    }
}