// Admin JS placeholder for Snow plugin
