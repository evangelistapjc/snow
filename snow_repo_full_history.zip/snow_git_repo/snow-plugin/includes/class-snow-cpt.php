<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class SNOW_CPT {
  public static function register(){
    register_post_type('snow_marketer', array(
      'label'=>'Marketers','public'=>false,'show_ui'=>true,'show_in_menu'=>false,'supports'=>array('title','editor')
    ));
    register_post_type('snow_abtest', array(
      'label'=>'A/B Tests','public'=>false,'show_ui'=>true,'show_in_menu'=>false,'supports'=>array('title','editor')
    ));
    register_post_type('snow_dependency', array(
      'label'=>'Dependencies','public'=>false,'show_ui'=>true,'show_in_menu'=>false,'supports'=>array('title','editor')
    ));
    register_taxonomy('snow_team', array('snow_marketer'), array(
      'label'=>'Teams','public'=>false,'show_ui'=>true,'hierarchical'=>true
    ));
  }
}