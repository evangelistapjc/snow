<?php
/**
 * Administrative UI and helpers for Intapp Snow.
 *
 * This module defines the WordPress admin menu pages, enqueues CSS/JS assets and
 * renders dashboard views for marketers, A/B tests and dependencies.  It also
 * contains a helper class for computing per‑marketer suggestions.  Much of the
 * code here is adapted from the Snow v0.4 prototype but updated to use the
 * Intapp post type prefixes and extended to support user linking and metric
 * imports.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Intapp_Snow_Admin {

    /**
     * Registers the top‑level and sub‑menu pages under the WordPress dashboard.
     */
    public static function register_menu() {
        add_menu_page( 'Intapp Snow', 'Intapp Snow', 'manage_options', 'intapp-snow-dashboard', array( __CLASS__, 'render_dashboard' ), 'dashicons-chart-line', 40 );
        add_submenu_page( 'intapp-snow-dashboard', 'A/B Tests', 'A/B Tests', 'manage_options', 'intapp-snow-abtests', array( __CLASS__, 'render_abtests' ) );
        add_submenu_page( 'intapp-snow-dashboard', 'Dependencies', 'Dependencies', 'manage_options', 'intapp-snow-deps', array( __CLASS__, 'render_deps' ) );
        add_submenu_page( 'intapp-snow-dashboard', 'Ingest', 'Ingest', 'manage_options', 'intapp-snow-ingest', array( 'Intapp_Snow_Ingest', 'render' ) );
        add_submenu_page( 'intapp-snow-dashboard', 'Integrations', 'Integrations', 'manage_options', 'intapp-snow-integrations', array( 'Intapp_Snow_Integrations', 'render_integrations' ) );
        add_submenu_page( 'intapp-snow-dashboard', 'Settings', 'Settings', 'manage_options', 'intapp-snow-settings', array( __CLASS__, 'render_settings' ) );
        add_submenu_page( 'intapp-snow-dashboard', 'Export', 'Export', 'manage_options', 'intapp-snow-export', array( __CLASS__, 'render_export' ) );

        // Campaigns
        add_submenu_page( 'intapp-snow-dashboard', 'Campaigns', 'Campaigns', 'manage_options', 'intapp-snow-campaigns', array( __CLASS__, 'render_campaigns' ) );
    }

    /**
     * Enqueues admin assets on Intapp Snow pages.  We keep the styling minimal and
     * scoped to the plugin's pages.  The CSS file defines a simple card layout
     * while the JS handles dynamic interactions (e.g., top suggestions refresh).
     *
     * @param string $hook The current admin page hook.
     */
    public static function enqueue_assets( $hook ) {
        if ( strpos( $hook, 'intapp-snow' ) === false ) {
            return;
        }
        wp_enqueue_style( 'intapp-snow-admin', INTAPP_SNOW_URL . 'assets/admin.css', array(), INTAPP_SNOW_VERSION );
        wp_enqueue_script( 'intapp-snow-admin', INTAPP_SNOW_URL . 'assets/admin.js', array( 'jquery' ), INTAPP_SNOW_VERSION, true );
    }

    /**
     * Renders the main dashboard page.  This view lists all marketers, their team,
     * KPIs and goals along with up to three suggested experiments.  Admins can
     * generate a Top‑5 list of experiments for a marketer with a button.  A
     * snapshot of the HubSpot integration (if enabled) is also displayed.
     */
    public static function render_dashboard() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $mode      = get_option( 'intapp_snow_mode', 'internal' );
        $marketers = get_posts( array( 'post_type' => 'intapp_marketer', 'numberposts' => -1 ) );
        ?>
        <div class="wrap snow-wrap">
            <h1>Intapp Snow Dashboard <span class="mode">Mode: <?php echo esc_html( strtoupper( $mode ) ); ?></span></h1>
            <div class="snow-grid">
                <div class="snow-card">
                    <h2>Marketers</h2>
                    <table class="wp-list-table widefat fixed striped">
                        <thead><tr><th>Name</th><th>Team</th><th>KPIs</th><th>Goals</th><th>Top 3 Suggestions</th><th>Actions</th></tr></thead>
                        <tbody>
                        <?php if ( $marketers ) : foreach ( $marketers as $m ) :
                            $team_terms = wp_get_post_terms( $m->ID, 'intapp_team', array( 'fields' => 'names' ) );
                            $kpis       = get_post_meta( $m->ID, 'snow_kpis', true );
                            $goals      = get_post_meta( $m->ID, 'snow_goals', true );
                            $top3       = Intapp_Snow_Admin_Helper::compute_top3( $m->ID );
                            ?>
                            <tr>
                                <td><strong><?php echo esc_html( get_the_title( $m ) ); ?></strong></td>
                                <td><?php echo esc_html( implode( ', ', $team_terms ) ); ?></td>
                                <td><?php echo esc_html( $kpis ? $kpis : '—' ); ?></td>
                                <td><?php echo esc_html( $goals ? $goals : '—' ); ?></td>
                                <td>
                                    <?php if ( $top3 ) : ?>
                                        <ol class="top3">
                                            <?php foreach ( $top3 as $idea ) : ?>
                                                <li><strong><?php echo esc_html( $idea['title'] ); ?></strong> (<?php echo intval( $idea['score'] ); ?>) – <?php echo esc_html( $idea['reason'] ); ?></li>
                                            <?php endforeach; ?>
                                        </ol>
                                    <?php else : ?>
                                        <em>No suggestions yet. Upload data or run Manual Sync.</em>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <form method="post">
                                        <?php wp_nonce_field( 'intapp_generate_top5_' . $m->ID ); ?>
                                        <input type="hidden" name="intapp_generate_top5" value="<?php echo esc_attr( $m->ID ); ?>" />
                                        <button class="button button-primary">Generate/Refresh Top 5</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; else : ?>
                            <tr><td colspan="6">No marketer profiles yet.</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
                <div class="snow-card">
                    <h2>HubSpot Snapshot</h2>
                    <?php $hs = get_option( 'intapp_snow_hubspot_cache', array() ); ?>
                    <?php if ( $hs ) : ?>
                        <table class="wp-list-table widefat fixed striped">
                            <thead><tr><th>Category</th><th>Count</th></tr></thead>
                            <tbody>
                            <?php foreach ( $hs as $k => $v ) :
                                $count = ( is_array( $v ) && isset( $v['count'] ) ) ? intval( $v['count'] ) : 0;
                                ?>
                                <tr><td><?php echo esc_html( $k ); ?></td><td><?php echo esc_html( $count ); ?></td></tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php else : ?>
                        <p>No HubSpot data synced yet.</p>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php
        // Handle generate Top 5 action.  The result inserts new A/B tests associated with the marketer.
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && ! empty( $_POST['intapp_generate_top5'] ) ) {
            $mid = intval( $_POST['intapp_generate_top5'] );
            if ( isset( $_POST['_wpnonce'] ) && wp_verify_nonce( $_POST['_wpnonce'], 'intapp_generate_top5_' . $mid ) ) {
                $ideas = Intapp_Snow_Admin_Helper::compute_topN( $mid, 5 );
                foreach ( $ideas as $idea ) {
                    $pid = wp_insert_post( array(
                        'post_type'    => 'intapp_abtest',
                        'post_title'   => sanitize_text_field( $idea['title'] ),
                        'post_content' => wp_kses_post( 'Hypothesis: ' . $idea['hypothesis'] . "\n" . 'Method: ' . $idea['method'] . "\n" . 'KPIs: ' . implode( ', ', $idea['kpis'] ) ),
                        'post_status'  => 'publish'
                    ) );
                    if ( $pid && ! is_wp_error( $pid ) ) {
                        update_post_meta( $pid, 'snow_owner', $mid );
                        update_post_meta( $pid, 'snow_dependencies', implode( ', ', $idea['deps'] ) );
                        update_post_meta( $pid, 'snow_score', $idea['score'] );
                    }
                }
                echo '<div class="notice notice-success"><p>Top 5 tests generated.</p></div>';
            }
        }
    }

    /**
     * Render the A/B Tests table.  Mirroring the core WordPress post list table, we show
     * basic fields along with the associated marketer and score.  Tests are stored
     * in the `intapp_abtest` post type.
     */
    public static function render_abtests() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $tests = get_posts( array( 'post_type' => 'intapp_abtest', 'numberposts' => -1 ) );
        ?>
        <div class="wrap snow-wrap"><h1>A/B Tests</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Title</th><th>Owner</th><th>Score</th><th>Dependencies</th><th>Created</th></tr></thead>
                <tbody>
                <?php if ( $tests ) : foreach ( $tests as $t ) :
                    $owner_id = get_post_meta( $t->ID, 'snow_owner', true );
                    $owner    = $owner_id ? get_the_title( $owner_id ) : '—';
                    $score    = get_post_meta( $t->ID, 'snow_score', true );
                    $deps     = get_post_meta( $t->ID, 'snow_dependencies', true );
                    ?>
                    <tr>
                        <td><a href="<?php echo esc_url( get_edit_post_link( $t->ID ) ); ?>"><?php echo esc_html( $t->post_title ); ?></a></td>
                        <td><?php echo esc_html( $owner ); ?></td>
                        <td><?php echo esc_html( $score ? $score : '—' ); ?></td>
                        <td><?php echo esc_html( $deps ? $deps : '—' ); ?></td>
                        <td><?php echo esc_html( get_the_date( '', $t ) ); ?></td>
                    </tr>
                <?php endforeach; else : ?>
                    <tr><td colspan="5">No tests yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Render the dependencies listing.  Dependencies are simple descriptive posts
     * representing resources or approvals required before running a test.  The list
     * shows title and a truncated description.
     */
    public static function render_deps() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $deps = get_posts( array( 'post_type' => 'intapp_dependency', 'numberposts' => -1 ) );
        ?>
        <div class="wrap snow-wrap"><h1>Dependencies</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Title</th><th>Description</th><th>Created</th></tr></thead>
                <tbody>
                <?php if ( $deps ) : foreach ( $deps as $d ) : ?>
                    <tr>
                        <td><a href="<?php echo esc_url( get_edit_post_link( $d->ID ) ); ?>"><?php echo esc_html( $d->post_title ); ?></a></td>
                        <td><?php echo esc_html( wp_trim_words( $d->post_content, 20 ) ); ?></td>
                        <td><?php echo esc_html( get_the_date( '', $d ) ); ?></td>
                    </tr>
                <?php endforeach; else : ?><tr><td colspan="3">No dependencies yet.</td></tr><?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Settings page for selecting operating mode.  Modes allow you to hide or
     * expose certain features (e.g. external vs internal data).  Currently two
     * modes exist: internal (full access) and external (sanitised).  Additional
     * modes can be added in the future.
     */
    public static function render_settings() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        if ( $_SERVER['REQUEST_METHOD'] === 'POST' && check_admin_referer( 'intapp_snow_settings' ) ) {
            $mode = isset( $_POST['intapp_snow_mode'] ) && in_array( $_POST['intapp_snow_mode'], array( 'internal', 'external' ), true )
                ? $_POST['intapp_snow_mode']
                : 'internal';
            update_option( 'intapp_snow_mode', $mode );
            echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
        }
        $mode = get_option( 'intapp_snow_mode', 'internal' );
        ?>
        <div class="wrap snow-wrap"><h1>Settings</h1>
            <form method="post">
                <?php wp_nonce_field( 'intapp_snow_settings' ); ?>
                <table class="form-table">
                    <tr><th><label for="intapp_snow_mode">Operating Mode</label></th>
                        <td><select name="intapp_snow_mode" id="intapp_snow_mode">
                                <option value="internal" <?php selected( $mode, 'internal' ); ?>>Internal (Full)</option>
                                <option value="external" <?php selected( $mode, 'external' ); ?>>External (Sanitised)</option>
                            </select></td></tr>
                </table>
                <p><button class="button button-primary">Save</button></p>
            </form>
        </div>
        <?php
    }

    /**
     * Render export page.  Currently exports a CSV formatted for Asana import via
     * Intapp_Snow_Export::handle_export() (see includes/class-intapp-snow-export.php).
     */
    public static function render_export() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        // Create a nonce for export and build admin URL.  This points to the export
        // handler which outputs a CSV for download.
        $nonce = wp_create_nonce( 'intapp_snow_export' );
        $url   = admin_url( 'admin-post.php?action=intapp_snow_export_asana&_wpnonce=' . $nonce );
        echo '<div class="wrap snow-wrap"><h1>Export</h1><p><a class="button button-primary" href="' . esc_url( $url ) . '">Download Asana CSV</a></p></div>';
    }

    /**
     * Render the campaigns listing table.  Campaigns are custom post types that
     * encapsulate optimisation initiatives driven by a senior developer or
     * optimisation lead.  Each campaign stores KPI baselines and projections,
     * business impact narratives and more via custom fields.
     */
    public static function render_campaigns() {
        if ( ! current_user_can( 'manage_options' ) ) {
            return;
        }
        $campaigns = get_posts( array( 'post_type' => 'intapp_campaign', 'numberposts' => -1 ) );
        ?>
        <div class="wrap snow-wrap"><h1>Campaigns</h1>
            <table class="wp-list-table widefat fixed striped">
                <thead><tr><th>Title</th><th>Owner</th><th>Baseline KPIs</th><th>Projected KPIs</th><th>Impact</th><th>Business Case</th><th>Future Holdings</th><th>Created</th></tr></thead>
                <tbody>
                <?php if ( $campaigns ) : foreach ( $campaigns as $c ) :
                    $owner_id   = get_post_meta( $c->ID, 'campaign_owner_user', true );
                    $owner_name = $owner_id ? ( ( $u = get_user_by( 'id', $owner_id ) ) ? $u->display_name : '' ) : '';
                    $baseline   = get_post_meta( $c->ID, 'kpi_baselines', true );
                    $projection = get_post_meta( $c->ID, 'kpi_projections', true );
                    $impact     = get_post_meta( $c->ID, 'impact', true );
                    $business   = get_post_meta( $c->ID, 'business_case', true );
                    $future     = get_post_meta( $c->ID, 'future_holdings', true );
                    ?>
                    <tr>
                        <td><a href="<?php echo esc_url( get_edit_post_link( $c->ID ) ); ?>"><?php echo esc_html( $c->post_title ); ?></a></td>
                        <td><?php echo esc_html( $owner_name ); ?></td>
                        <td><?php echo esc_html( $baseline ? ( is_array( $baseline ) ? implode( '; ', $baseline ) : $baseline ) : '—' ); ?></td>
                        <td><?php echo esc_html( $projection ? ( is_array( $projection ) ? implode( '; ', $projection ) : $projection ) : '—' ); ?></td>
                        <td><?php echo esc_html( $impact ? wp_trim_words( $impact, 10 ) : '—' ); ?></td>
                        <td><?php echo esc_html( $business ? wp_trim_words( $business, 10 ) : '—' ); ?></td>
                        <td><?php echo esc_html( $future ? wp_trim_words( $future, 10 ) : '—' ); ?></td>
                        <td><?php echo esc_html( get_the_date( '', $c ) ); ?></td>
                    </tr>
                <?php endforeach; else : ?>
                    <tr><td colspan="8">No campaigns yet.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
        <?php
    }

    /**
     * Register meta boxes for campaigns.  Hooked into add_meta_boxes.
     */
    public static function add_campaign_metaboxes() {
        add_meta_box( 'intapp_campaign_details', __( 'Campaign Details', 'intapp-snow' ), array( __CLASS__, 'render_campaign_metabox' ), 'intapp_campaign', 'normal', 'default' );
    }

    /**
     * Render the campaign meta box.  Provides fields for owner (WP user), KPI
     * baselines and projections (comma separated values), impact narrative,
     * business case and future holdings.  Note: we do not escape output here
     * because WordPress will handle it in admin context; we sanitise on save.
     *
     * @param WP_Post $post The campaign post being edited.
     */
    public static function render_campaign_metabox( $post ) {
        // Nonce for verification
        wp_nonce_field( 'intapp_campaign_meta', 'intapp_campaign_meta_nonce' );
        // Load existing meta
        $owner_id   = get_post_meta( $post->ID, 'campaign_owner_user', true );
        $baseline   = get_post_meta( $post->ID, 'kpi_baselines', true );
        $projection = get_post_meta( $post->ID, 'kpi_projections', true );
        $impact     = get_post_meta( $post->ID, 'impact', true );
        $business   = get_post_meta( $post->ID, 'business_case', true );
        $future     = get_post_meta( $post->ID, 'future_holdings', true );
        // Fetch all users for selection
        $users      = get_users( array( 'fields' => array( 'ID', 'display_name' ) ) );
        ?>
        <p>
            <label for="intapp_campaign_owner">Owner (WP User)</label><br/>
            <select name="intapp_campaign_owner" id="intapp_campaign_owner" class="widefat">
                <option value="">— Select —</option>
                <?php foreach ( $users as $u ) : ?>
                    <option value="<?php echo esc_attr( $u->ID ); ?>" <?php selected( $owner_id, $u->ID ); ?>><?php echo esc_html( $u->display_name ); ?></option>
                <?php endforeach; ?>
            </select>
        </p>
        <p>
            <label for="intapp_campaign_baselines">Baseline KPIs (comma separated)</label><br/>
            <input type="text" name="intapp_campaign_baselines" id="intapp_campaign_baselines" class="widefat" value="<?php echo esc_attr( is_array( $baseline ) ? implode( ', ', $baseline ) : $baseline ); ?>" />
        </p>
        <p>
            <label for="intapp_campaign_projections">Projected KPIs (comma separated)</label><br/>
            <input type="text" name="intapp_campaign_projections" id="intapp_campaign_projections" class="widefat" value="<?php echo esc_attr( is_array( $projection ) ? implode( ', ', $projection ) : $projection ); ?>" />
        </p>
        <p>
            <label for="intapp_campaign_impact">Impact to Business</label><br/>
            <textarea name="intapp_campaign_impact" id="intapp_campaign_impact" class="widefat" rows="3"><?php echo esc_textarea( $impact ); ?></textarea>
        </p>
        <p>
            <label for="intapp_campaign_business">Business Case</label><br/>
            <textarea name="intapp_campaign_business" id="intapp_campaign_business" class="widefat" rows="3"><?php echo esc_textarea( $business ); ?></textarea>
        </p>
        <p>
            <label for="intapp_campaign_future">Future Holdings</label><br/>
            <textarea name="intapp_campaign_future" id="intapp_campaign_future" class="widefat" rows="3"><?php echo esc_textarea( $future ); ?></textarea>
        </p>
        <?php
    }

    /**
     * Save campaign meta when the post is saved.  Hooked into save_post_intapp_campaign.
     *
     * @param int $post_id The post ID.
     */
    public static function save_campaign_meta( $post_id ) {
        // Check nonce
        if ( ! isset( $_POST['intapp_campaign_meta_nonce'] ) || ! wp_verify_nonce( $_POST['intapp_campaign_meta_nonce'], 'intapp_campaign_meta' ) ) {
            return;
        }
        // Don't save during autosave or AJAX
        if ( defined( 'DOING_AUTOSAVE' ) && DOING_AUTOSAVE ) {
            return;
        }
        if ( ! current_user_can( 'edit_post', $post_id ) ) {
            return;
        }
        // Owner
        $owner = isset( $_POST['intapp_campaign_owner'] ) ? intval( $_POST['intapp_campaign_owner'] ) : 0;
        if ( $owner ) {
            update_post_meta( $post_id, 'campaign_owner_user', $owner );
        } else {
            delete_post_meta( $post_id, 'campaign_owner_user' );
        }
        // Baselines
        $baselines = isset( $_POST['intapp_campaign_baselines'] ) ? sanitize_text_field( $_POST['intapp_campaign_baselines'] ) : '';
        $baseline_arr = array_filter( array_map( 'trim', explode( ',', $baselines ) ) );
        if ( ! empty( $baseline_arr ) ) {
            update_post_meta( $post_id, 'kpi_baselines', $baseline_arr );
        } else {
            delete_post_meta( $post_id, 'kpi_baselines' );
        }
        // Projections
        $projections = isset( $_POST['intapp_campaign_projections'] ) ? sanitize_text_field( $_POST['intapp_campaign_projections'] ) : '';
        $proj_arr     = array_filter( array_map( 'trim', explode( ',', $projections ) ) );
        if ( ! empty( $proj_arr ) ) {
            update_post_meta( $post_id, 'kpi_projections', $proj_arr );
        } else {
            delete_post_meta( $post_id, 'kpi_projections' );
        }
        // Impact
        if ( isset( $_POST['intapp_campaign_impact'] ) ) {
            $impact = sanitize_textarea_field( $_POST['intapp_campaign_impact'] );
            if ( $impact ) {
                update_post_meta( $post_id, 'impact', $impact );
            } else {
                delete_post_meta( $post_id, 'impact' );
            }
        }
        // Business case
        if ( isset( $_POST['intapp_campaign_business'] ) ) {
            $business = sanitize_textarea_field( $_POST['intapp_campaign_business'] );
            if ( $business ) {
                update_post_meta( $post_id, 'business_case', $business );
            } else {
                delete_post_meta( $post_id, 'business_case' );
            }
        }
        // Future holdings
        if ( isset( $_POST['intapp_campaign_future'] ) ) {
            $future = sanitize_textarea_field( $_POST['intapp_campaign_future'] );
            if ( $future ) {
                update_post_meta( $post_id, 'future_holdings', $future );
            } else {
                delete_post_meta( $post_id, 'future_holdings' );
            }
        }
    }
}

/**
 * Helper class for computing per‑marketer metrics and generating suggestions.  The
 * scoring heuristics live in Intapp_Snow_Scorer; this helper simply fetches
 * metric data from caches populated via integrations or uploads and passes
 * them to the scorer.  See class-intapp-snow-ingest.php for how caches are
 * updated on CSV upload.
 */
class Intapp_Snow_Admin_Helper {
    /**
     * Return merged metrics for a marketer.  Metrics come from two sources: a
     * marketer‑specific cache (`snow_marketer_cache_{id}`) populated by
     * integrations like HubSpot, and an organisational upload cache
     * (`snow_upload_cache_org`) populated by manual CSV upload.  Both caches
     * live in the WordPress options table.  You can extend this method to
     * combine additional sources if needed.
     *
     * @param int $marketer_id The marketer post ID.
     * @return array Merged metrics array.
     */
    public static function marketer_metrics( $marketer_id ) {
        $m = get_option( 'snow_marketer_cache_' . $marketer_id, array() );
        $u = get_option( 'snow_upload_cache_org', array() );
        $merged = array();
        if ( ! empty( $m['data'] ) ) {
            $merged = array_merge( $merged, $m['data'] );
        }
        if ( ! empty( $u['data'] ) && is_array( $u['data'] ) ) {
            // We don't merge raw uploaded rows; instead we expose the count for context.
            $merged['uploaded_rows'] = is_array( $u['data'] ) ? count( $u['data'] ) : 0;
        }
        return $merged;
    }

    /**
     * Compute the top 3 suggestions for a marketer based off their metrics.  This is
     * a convenience wrapper around the scorer.  Suggestions are sorted by
     * descending score.
     *
     * @param int $marketer_id Marketer post ID.
     * @return array Array of up to three suggestion arrays (title, hypothesis, etc.).
     */
    public static function compute_top3( $marketer_id ) {
        $metrics = self::marketer_metrics( $marketer_id );
        $ideas   = Intapp_Snow_Scorer::suggest_for_marketer( $marketer_id, $metrics );
        return array_slice( $ideas, 0, 3 );
    }

    /**
     * Compute the top N suggestions for a marketer.  See compute_top3().
     *
     * @param int $marketer_id Marketer post ID.
     * @param int $n Number of suggestions to return.
     * @return array Array of suggestions.
     */
    public static function compute_topN( $marketer_id, $n ) {
        $metrics = self::marketer_metrics( $marketer_id );
        $ideas   = Intapp_Snow_Scorer::suggest_for_marketer( $marketer_id, $metrics );
        return array_slice( $ideas, 0, $n );
    }
}