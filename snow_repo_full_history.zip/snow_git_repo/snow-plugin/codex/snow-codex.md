# SNOW Codex

Unified role-inclusive CRO/A/B testing framework.
