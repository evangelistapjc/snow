<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class SNOW_Export {
  public static function handle_export(){
    if (! current_user_can('manage_options')) wp_die('Unauthorized');
    check_admin_referer('snow_export_asana');
    $tests = get_posts(array('post_type'=>'snow_abtest','numberposts'=>-1));
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="snow_asana_export.csv"');
    $out = fopen('php://output','w');
    fputcsv($out, array('Name','Notes','Assignee','Due Date','Projects','Section/Column','Dependencies','Custom Field: Team','Custom Field: KPI','Custom Field: Priority'));
    foreach($tests as $t){
      $owner_id = get_post_meta($t->ID,'snow_owner',true);
      $owner = $owner_id ? get_the_title($owner_id) : '';
      $team = $owner_id ? implode(', ', wp_get_post_terms($owner_id,'snow_team',array('fields'=>'names'))) : '';
      $deps = get_post_meta($t->ID,'snow_dependencies',true);
      fputcsv($out, array($t->post_title, wp_strip_all_tags($t->post_content), $owner, '', 'A/B Experimentation','Backlog', $deps, $team, 'CRO','High'));
    }
    fclose($out);
    exit;
  }
}