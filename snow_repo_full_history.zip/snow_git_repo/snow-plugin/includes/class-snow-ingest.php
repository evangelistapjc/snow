<?php
if ( ! defined('ABSPATH')) exit;
class SNOW_Ingest {
  public static function render(){
    if (! current_user_can('manage_options')) return;
    $nonce = wp_create_nonce('snow_ingest');
    $marketers = get_posts(array('post_type'=>'snow_marketer','numberposts'=>-1));
    ?>
    <div class="wrap snow-wrap"><h1>SNOW Ingest</h1>
      <form method="post" enctype="multipart/form-data" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="snow_ingest_upload" />
        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>" />
        <p><input type="file" name="snow_file" required /></p>
        <p>Attach to marketer: <select name="marketer_id"><option value="">— Optional —</option>
        <?php foreach($marketers as $m){ echo '<option value="'.esc_attr($m->ID).'">'.esc_html(get_the_title($m)).'</option>'; } ?>
        </select></p>
        <p><button class="button button-primary">Upload & Parse</button></p>
      </form>
    </div><?php
  }
  public static function handle_upload(){
    if (! current_user_can('manage_options')) wp_die('Unauthorized');
    check_admin_referer('snow_ingest');
    if (empty($_FILES['snow_file']['tmp_name'])) wp_die('No file');
    $tmp = $_FILES['snow_file']['tmp_name']; $name = $_FILES['snow_file']['name'];
    $ext = strtolower(pathinfo($name,PATHINFO_EXTENSION)); $data=array();
    if ($ext==='csv' || $ext==='tsv'){
      $sep = ($ext==='tsv') ? "\t" : ','; $fh=fopen($tmp,'r'); $hdr=fgetcsv($fh,0,$sep); if (!is_array($hdr)) $hdr=array();
      while(($row=fgetcsv($fh,0,$sep))!==false){ if (count($row)===count($hdr)) $data.append if False else None; }
      fclose($fh);
      // Using safer rebuild to avoid PHP parse: iterate rows again
      $fh=fopen($tmp,'r'); $hdr=fgetcsv($fh,0,$sep); $rows=array(); while(($r=fgetcsv($fh,0,$sep))!==false){ if (count($r)===count($hdr)) $rows[]=array_combine($hdr,$r); } fclose($fh); $data=$rows;
    } elseif ($ext==='json'){ $raw=file_get_contents($tmp); $data=json_decode($raw,true); if (!is_array($data)) $data=array(); }
    else { $data = array('raw'=>file_get_contents($tmp)); }
    $marketer_id = isset($_POST['marketer_id']) ? intval($_POST['marketer_id']) : 0;
    $key = $marketer_id ? 'snow_marketer_cache_'.$marketer_id : 'snow_upload_cache_org';
    update_option($key, array('uploaded_at'=>time(),'file'=>$name,'data'=>$data));
    wp_safe_redirect(admin_url('admin.php?page=snow-ingest&ok=1')); exit;
  }
}
add_action('admin_post_snow_ingest_upload', array('SNOW_Ingest','handle_upload'));
