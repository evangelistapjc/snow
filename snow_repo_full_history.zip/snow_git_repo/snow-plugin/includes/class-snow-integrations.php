<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }
class SNOW_Integrations {
  const OPTION_KEY = 'snow_integrations';
  public static function render_integrations(){
    if (! current_user_can('manage_options')) return;
    $o = get_option(self::OPTION_KEY, array());
    $o = wp_parse_args($o, array('hubspot'=>array('enabled'=>false,'api_key'=>'','portal_id'=>'')));
    $nonce = wp_create_nonce('snow_integrations');
    ?>
    <div class="wrap snow-wrap"><h1>Integrations</h1>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="snow_integrations_save" />
        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>" />
        <h2>HubSpot</h2>
        <label><input type="checkbox" name="hubspot_enabled" <?php checked(!empty($o['hubspot']['enabled'])); ?> /> Enable</label><br/>
        <input type="password" name="hubspot_api_key" value="<?php echo esc_attr($o['hubspot']['api_key']); ?>" placeholder="Private App Token" class="regular-text" />
        <input type="text" name="hubspot_portal_id" value="<?php echo esc_attr($o['hubspot']['portal_id']); ?>" placeholder="Portal ID" class="regular-text" />
        <p><button class="button button-primary">Save</button></p>
      </form>
      <form method="post" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
        <input type="hidden" name="action" value="snow_integrations_sync" />
        <input type="hidden" name="_wpnonce" value="<?php echo esc_attr($nonce); ?>" />
        <p><button class="button">Run Manual Sync</button></p>
      </form>
    </div>
    <?php
  }
}
add_action('admin_post_snow_integrations_save', function(){
  if (! current_user_can('manage_options')) wp_die('Unauthorized');
  check_admin_referer('snow_integrations');
  $o = get_option(SNOW_Integrations::OPTION_KEY, array());
  $o['hubspot']['enabled'] = isset($_POST['hubspot_enabled']);
  $o['hubspot']['api_key'] = sanitize_text_field($_POST['hubspot_api_key'] ?? '');
  $o['hubspot']['portal_id'] = sanitize_text_field($_POST['hubspot_portal_id'] ?? '');
  update_option(SNOW_Integrations::OPTION_KEY, $o);
  wp_safe_redirect(admin_url('admin.php?page=snow-integrations&updated=1')); exit;
});
add_action('admin_post_snow_integrations_sync', function(){
  if (! current_user_can('manage_options')) wp_die('Unauthorized');
  check_admin_referer('snow_integrations');
  $o = get_option(SNOW_Integrations::OPTION_KEY, array());
  $o = wp_parse_args($o, array('hubspot'=>array('enabled'=>false,'api_key'=>'')));
  if (!empty($o['hubspot']['enabled']) && !empty($o['hubspot']['api_key'])){
    SNOW_Integration_HubSpot::sync($o['hubspot']);
  }
  wp_safe_redirect(admin_url('admin.php?page=snow-integrations&synced=1')); exit;
});
