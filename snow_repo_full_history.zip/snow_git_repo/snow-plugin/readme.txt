=== SNOW Plugin (CRO/A-B Ops Framework) ===
Contributors: peej, kai
Tags: cro, ab testing, marketing ops, kpi, integrations
Requires at least: 5.8
Tested up to: 6.x
Stable tag: 0.4.1
License: GPLv2
Text Domain: snow

== Description ==
Unified, role-inclusive CRO/A/B testing framework for Marketing Ops teams. Per-marketer dashboards, Top-3 suggestions (ephemeral), Top-5 persisted tests, safe integrations (HubSpot sample), file ingest, and Asana CSV export. Safe to activate/deactivate.

== Installation ==
1. Upload `snow-plugin` to `/wp-content/plugins/` or install zip.
2. Activate plugin.
3. Go to SNOW → Settings to choose mode.
4. Optional: SNOW → Integrations to enable HubSpot (staging token supported).

== Screenshots ==
1. SNOW Dashboard (Marketers + Top 3)
2. HubSpot Snapshot
3. A/B Tests list

== Changelog ==
= 0.4.1 =
- Added full team placeholders, safer ingest, and static preview.

== Privacy ==
No PII is displayed; only aggregate counts. External calls are opt-in and read-only by default.
