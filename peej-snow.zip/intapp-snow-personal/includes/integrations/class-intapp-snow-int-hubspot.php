<?php
/**
 * HubSpot integration for Intapp Snow.
 *
 * This class encapsulates a one‑way sync from HubSpot into the Snow caches.
 * When run, it fetches summary counts of forms, lists, workflows and other
 * objects via HubSpot's public API using a private app token.  It also seeds
 * placeholder metric caches for each marketer.  All API calls are read‑only.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Peej_Snow_Integration_HubSpot {
    /**
     * Fetch summary data from HubSpot and cache it.  Also populates per‑marketer
     * caches with placeholder metrics appropriate for the scoring heuristics.  The
     * $cfg array must include a `api_key` (private app token).  Portal ID is
     * accepted but not currently used.
     *
     * @param array $cfg Integration configuration.
     * @return bool True on success, false on failure.
     */
    public static function sync( $cfg ) {
        $token = trim( $cfg['api_key'] );
        if ( empty( $token ) ) {
            return false;
        }
        $headers = array(
            'Authorization' => 'Bearer ' . $token,
            'Content-Type'  => 'application/json'
        );
        // Perform API calls.  We suppress errors and simply return empty arrays on failure.
        $forms      = self::get_json( 'https://api.hubapi.com/marketing/v3/forms', $headers );
        $lists      = self::get_json( 'https://api.hubapi.com/contacts/v1/lists?count=50', $headers );
        $workflows  = self::get_json( 'https://api.hubapi.com/automation/v3/workflows', $headers );
        $events     = self::get_json( 'https://api.hubapi.com/events/v3/events', $headers );
        $chatflows  = self::get_json( 'https://api.hubapi.com/chatflows/v3/flows', $headers );
        $dashboards = self::get_json( 'https://api.hubapi.com/dashboardapi/v3/dashboards', $headers );
        update_option( 'peej_snow_hubspot_cache', array(
            'forms'                 => array( 'count' => isset( $forms['results'] ) ? count( $forms['results'] ) : 0 ),
            'lists'                 => array( 'count' => isset( $lists['lists'] ) ? count( $lists['lists'] ) : 0 ),
            'workflows'             => array( 'count' => isset( $workflows['results'] ) ? count( $workflows['results'] ) : 0 ),
            'custom_behavioral_events' => array( 'count' => isset( $events['results'] ) ? count( $events['results'] ) : 0 ),
            'chatbots'              => array( 'count' => isset( $chatflows['flows'] ) ? count( $chatflows['flows'] ) : 0 ),
            'dashboards'            => array( 'count' => isset( $dashboards['results'] ) ? count( $dashboards['results'] ) : 0 ),
        ), false );
        // Populate marketer caches with placeholder metrics.  In a real integration you
        // would map HubSpot analytics fields to the metrics used in the scoring
        // heuristics.  Here we simply set default values to illustrate the flow.
        $marketers = get_posts( array( 'post_type' => 'peej_marketer', 'numberposts' => -1 ) );
        foreach ( $marketers as $m ) {
            $metrics = array(
                'forms_count'             => isset( $forms['results'] ) ? count( $forms['results'] ) : 0,
                'form_drop_rate'          => 0.55,
                'form_views'              => 2500,
                'sessions'                => 8000,
                'reg_cvr'                 => 0.06,
                'persona_sources'         => 1,
                'wistia_plays'            => 0,
                'turnstile_cvr'           => 0,
                'email_sends'             => 20000,
                'email_ctor'              => 0.10,
                'lcp_ms'                  => 3200,
                'dep_analytics_form_submit' => 1,
                'dep_privacy_ok'          => 1,
                'dep_copy_approved'       => 0,
                'dep_optimizely_project'  => 0,
                'dep_wistia_access'       => 0,
                'dep_email_template_access' => 1,
                'dep_perf_budget'         => 1,
                'dep_image_assets'        => 0
            );
            update_option( 'snow_marketer_cache_' . $m->ID, array( 'updated_at' => time(), 'data' => $metrics ), false );
        }
        return true;
    }

    /**
     * Helper to perform a GET request and decode JSON.  Returns an empty array on
     * error or non‑200 responses.
     *
     * @param string $url API endpoint.
     * @param array $headers HTTP headers.
     * @return array Decoded JSON response.
     */
    private static function get_json( $url, $headers ) {
        $resp = wp_remote_get( $url, array( 'headers' => $headers, 'timeout' => 20 ) );
        if ( is_wp_error( $resp ) ) {
            return array();
        }
        if ( wp_remote_retrieve_response_code( $resp ) !== 200 ) {
            return array();
        }
        $j = json_decode( wp_remote_retrieve_body( $resp ), true );
        return is_array( $j ) ? $j : array();
    }
}