<?php
/**
 * Plugin Name: Intapp Snow (CRO/A‑B Ops Framework)
 * Description: Unified marketing operations framework inspired by the Snow prototype.  
 *              Includes per‑marketer dashboards, A/B test management, metrics import and scoring,
 *              team taxonomies and user linking.  Works with or without Advanced Custom Fields
 *              and provides a modular integration system ready for third‑party APIs (HubSpot,
 *              Asana, etc.).
 * Version: 0.6.1
 * Author: Peej
 * License: GPL2
 * Text Domain: intapp-snow
 */

// Prevent direct access
if ( ! defined( 'ABSPATH' ) ) { exit; }

/**
 * Define constants for easier path resolution.  These constants are scoped to this plugin
 * and won't conflict with other Snow variations.
 */
// Keep this in sync with the version header above.  This constant is used for cache‑busting assets.
define( 'INTAPP_SNOW_VERSION', '0.6.1' );
define( 'INTAPP_SNOW_DIR', plugin_dir_path( __FILE__ ) );
define( 'INTAPP_SNOW_URL', plugin_dir_url( __FILE__ ) );

// Load dependencies.  Each class encapsulates a discrete area of functionality to keep the
// plugin modular.  You can drop in additional integration classes under includes/integrations.
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-cpt.php';
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-admin.php';
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-ingest.php';
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-integrations.php';
// Load default integration classes.  Additional integrations can be added by
// creating files under includes/integrations and requiring them here.
require_once INTAPP_SNOW_DIR . 'includes/integrations/class-intapp-snow-int-hubspot.php';
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-sampledata.php';
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-scorer.php';
require_once INTAPP_SNOW_DIR . 'includes/class-intapp-snow-export.php';

/**
 * The main bootstrapper for Intapp Snow.  This class simply wires the hooks up to the
 * appropriate static methods.  All heavy lifting happens in the included classes.
 */
class Intapp_Snow_Plugin {
    public function __construct() {
        // Register custom post types and taxonomies
        add_action( 'init', array( 'Intapp_Snow_CPT', 'register' ) );

        // Admin menus and assets
        add_action( 'admin_menu', array( 'Intapp_Snow_Admin', 'register_menu' ) );
        add_action( 'admin_enqueue_scripts', array( 'Intapp_Snow_Admin', 'enqueue_assets' ) );

        // Register campaign meta boxes and save handlers.  These hooks live here
        // because they rely on the admin class but must be registered on every
        // request.  Without them, the campaign custom fields would not appear.
        add_action( 'add_meta_boxes', array( 'Intapp_Snow_Admin', 'add_campaign_metaboxes' ) );
        add_action( 'save_post_intapp_campaign', array( 'Intapp_Snow_Admin', 'save_campaign_meta' ) );

        // Data ingest handler
        add_action( 'admin_post_intapp_snow_ingest_upload', array( 'Intapp_Snow_Ingest', 'handle_upload' ) );

        // Activate/deactivate hooks
        register_activation_hook( __FILE__, array( $this, 'on_activate' ) );
        register_deactivation_hook( __FILE__, array( $this, 'on_deactivate' ) );
    }

    public function on_activate() {
        // Ensure CPTs and taxonomies are registered before flushing rewrites
        Intapp_Snow_CPT::register();
        flush_rewrite_rules();
        // If plugin is first activated, seed sample data for demonstration.  You can remove
        // these seeds safely after experimentation.
        Intapp_Snow_SampleData::seed();
    }

    public function on_deactivate() {
        flush_rewrite_rules();
    }
}

// Instantiate the plugin singleton
new Intapp_Snow_Plugin();