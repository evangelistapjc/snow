<?php
/**
 * CSV export functionality for Intapp Snow.
 *
 * Exports all A/B tests into a CSV formatted for import into Asana.  This
 * provides a lightweight bridge between WordPress and task management tools.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Intapp_Snow_Export {
    public static function handle_export() {
        if ( ! current_user_can( 'manage_options' ) ) {
            wp_die( 'Unauthorized' );
        }
        check_admin_referer( 'intapp_snow_export' );
        $tests = get_posts( array( 'post_type' => 'intapp_abtest', 'numberposts' => -1 ) );
        header( 'Content-Type: text/csv' );
        header( 'Content-Disposition: attachment; filename="intapp_snow_asana_export.csv"' );
        $out = fopen( 'php://output', 'w' );
        // CSV header fields for Asana.  Adjust custom fields to match your Asana setup.
        fputcsv( $out, array( 'Name', 'Notes', 'Assignee', 'Due Date', 'Projects', 'Section/Column', 'Dependencies', 'Custom Field: Team', 'Custom Field: KPI', 'Custom Field: Priority' ) );
        foreach ( $tests as $t ) {
            $owner_id = get_post_meta( $t->ID, 'snow_owner', true );
            $owner    = $owner_id ? get_the_title( $owner_id ) : '';
            $team     = $owner_id ? implode( ', ', wp_get_post_terms( $owner_id, 'intapp_team', array( 'fields' => 'names' ) ) ) : '';
            $deps     = get_post_meta( $t->ID, 'snow_dependencies', true );
            fputcsv( $out, array( $t->post_title, wp_strip_all_tags( $t->post_content ), $owner, '', 'A/B Experimentation', 'Backlog', $deps, $team, 'CRO', 'High' ) );
        }
        fclose( $out );
        exit;
    }
}

// Register export handler
add_action( 'admin_post_intapp_snow_export_asana', array( 'Intapp_Snow_Export', 'handle_export' ) );