<?php
if ( ! defined( 'ABSPATH' ) ) { exit; }

class SNOW_Admin {
  public static function register_menu(){
    add_menu_page('SNOW','SNOW','manage_options','snow-dashboard',array(__CLASS__,'render_dashboard'),'dashicons-chart-line',40);
    add_submenu_page('snow-dashboard','A/B Tests','A/B Tests','manage_options','snow-abtests',array(__CLASS__,'render_abtests'));
    add_submenu_page('snow-dashboard','Dependencies','Dependencies','manage_options','snow-deps',array(__CLASS__,'render_deps'));
    add_submenu_page('snow-dashboard','Ingest','Ingest','manage_options','snow-ingest',array('SNOW_Ingest','render'));
    add_submenu_page('snow-dashboard','Integrations','Integrations','manage_options','snow-integrations',array('SNOW_Integrations','render_integrations'));
    add_submenu_page('snow-dashboard','Settings','Settings','manage_options','snow-settings',array(__CLASS__,'render_settings'));
    add_submenu_page('snow-dashboard','Export to Asana','Export to Asana','manage_options','snow-export',array(__CLASS__,'render_export'));
  }
  public static function enqueue_assets($hook){
    if (strpos($hook,'snow')===false) return;
    wp_enqueue_style('snow-admin', SNOW_PLUGIN_URL.'assets/admin.css', array(), SNOW_PLUGIN_VERSION);
    wp_enqueue_script('snow-admin', SNOW_PLUGIN_URL.'assets/admin.js', array('jquery'), SNOW_PLUGIN_VERSION, true);
  }
  public static function render_dashboard(){
    if (! current_user_can('manage_options')) return;
    $mode = get_option('snow_mode','intapp');
    $marketers = get_posts(array('post_type'=>'snow_marketer','numberposts'=>-1));
    ?>
    <div class="wrap snow-wrap">
      <h1>SNOW Dashboard <span class="mode">Mode: <?php echo esc_html(strtoupper($mode)); ?></span></h1>
      <div class="snow-grid">
        <div class="snow-card">
          <h2>Marketers</h2>
          <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Name</th><th>Team</th><th>KPIs</th><th>Goals</th><th>Top 3</th><th>Actions</th></tr></thead>
            <tbody>
            <?php if ($marketers): foreach($marketers as $m):
              $team_terms = wp_get_post_terms($m->ID, 'snow_team', array('fields'=>'names'));
              $kpis = get_post_meta($m->ID,'snow_kpis',true);
              $goals = get_post_meta($m->ID,'snow_goals',true);
              $top3 = SNOW_Admin_Helper::compute_top3($m->ID);
            ?>
              <tr>
                <td><strong><?php echo esc_html(get_the_title($m)); ?></strong></td>
                <td><?php echo esc_html(implode(', ', $team_terms)); ?></td>
                <td><?php echo esc_html($kpis ? $kpis : '—'); ?></td>
                <td><?php echo esc_html($goals ? $goals : '—'); ?></td>
                <td>
                  <?php if ($top3): ?>
                    <ol class="top3">
                      <?php foreach($top3 as $idea): ?>
                        <li><strong><?php echo esc_html($idea['title']); ?></strong> (<?php echo intval($idea['score']); ?>) – <?php echo esc_html($idea['reason']); ?></li>
                      <?php endforeach; ?>
                    </ol>
                  <?php else: ?>
                    <em>No suggestions yet. Run Manual Sync or upload data.</em>
                  <?php endif; ?>
                </td>
                <td>
                  <form method="post">
                    <?php wp_nonce_field('snow_generate_top5_'.$m->ID); ?>
                    <input type="hidden" name="snow_generate_top5" value="<?php echo esc_attr($m->ID); ?>" />
                    <button class="button button-primary">Generate/Refresh Top 5</button>
                  </form>
                </td>
              </tr>
            <?php endforeach; else: ?>
              <tr><td colspan="6">No marketer profiles yet.</td></tr>
            <?php endif; ?>
            </tbody>
          </table>
        </div>
        <div class="snow-card">
          <h2>HubSpot Snapshot</h2>
          <?php $hs = get_option('snow_hubspot_cache', array()); ?>
          <?php if ($hs): ?>
          <table class="wp-list-table widefat fixed striped">
            <thead><tr><th>Category</th><th>Count</th></tr></thead>
            <tbody>
              <?php foreach($hs as $k=>$v): $count = (is_array($v) && isset($v['count'])) ? intval($v['count']) : 0; ?>
                <tr><td><?php echo esc_html($k); ?></td><td><?php echo esc_html($count); ?></td></tr>
              <?php endforeach; ?>
            </tbody>
          </table>
          <?php else: ?><p>No HubSpot data synced yet.</p><?php endif; ?>
        </div>
      </div>
    </div>
    <?php
    // Handle generate Top 5
    if ($_SERVER['REQUEST_METHOD']==='POST' && !empty($_POST['snow_generate_top5'])){
      $mid = intval($_POST['snow_generate_top5']);
      if (isset($_POST['_wpnonce']) && wp_verify_nonce($_POST['_wpnonce'],'snow_generate_top5_'.$mid)){
        $ideas = SNOW_Admin_Helper::compute_topN($mid,5);
        foreach($ideas as $idea){
          $pid = wp_insert_post(array(
            'post_type'=>'snow_abtest',
            'post_title'=> sanitize_text_field($idea['title']),
            'post_content'=> wp_kses_post('Hypothesis: '.$idea['hypothesis']."
".'Method: '.$idea['method']."
".'KPIs: '.implode(', ',$idea['kpis'])),
            'post_status'=>'publish'
          ));
          if ($pid && !is_wp_error($pid)){
            update_post_meta($pid,'snow_owner',$mid);
            update_post_meta($pid,'snow_dependencies', implode(', ',$idea['deps']));
            update_post_meta($pid,'snow_score',$idea['score']);
          }
        }
        echo '<div class="notice notice-success"><p>Top 5 tests generated.</p></div>';
      }
    }
  }

  public static function render_abtests(){
    if (! current_user_can('manage_options')) return;
    $tests = get_posts(array('post_type'=>'snow_abtest','numberposts'=>-1));
    ?>
    <div class="wrap snow-wrap"><h1>A/B Tests</h1>
      <table class="wp-list-table widefat fixed striped">
        <thead><tr><th>Title</th><th>Owner</th><th>Score</th><th>Dependencies</th><th>Created</th></tr></thead>
        <tbody>
        <?php if ($tests): foreach($tests as $t):
          $owner_id = get_post_meta($t->ID,'snow_owner',true);
          $owner = $owner_id ? get_the_title($owner_id) : '—';
          $score = get_post_meta($t->ID,'snow_score',true);
          $deps = get_post_meta($t->ID,'snow_dependencies',true);
        ?>
          <tr>
            <td><a href="<?php echo esc_url(get_edit_post_link($t->ID)); ?>"><?php echo esc_html($t->post_title); ?></a></td>
            <td><?php echo esc_html($owner); ?></td>
            <td><?php echo esc_html($score ? $score : '—'); ?></td>
            <td><?php echo esc_html($deps ? $deps : '—'); ?></td>
            <td><?php echo esc_html(get_the_date('', $t)); ?></td>
          </tr>
        <?php endforeach; else: ?>
          <tr><td colspan="5">No tests yet.</td></tr>
        <?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php
  }

  public static function render_deps(){
    if (! current_user_can('manage_options')) return;
    $deps = get_posts(array('post_type'=>'snow_dependency','numberposts'=>-1));
    ?>
    <div class="wrap snow-wrap"><h1>Dependencies</h1>
      <table class="wp-list-table widefat fixed striped">
        <thead><tr><th>Title</th><th>Description</th><th>Created</th></tr></thead>
        <tbody>
        <?php if ($deps): foreach($deps as $d): ?>
          <tr>
            <td><a href="<?php echo esc_url(get_edit_post_link($d->ID)); ?>"><?php echo esc_html($d->post_title); ?></a></td>
            <td><?php echo esc_html(wp_trim_words($d->post_content, 20)); ?></td>
            <td><?php echo esc_html(get_the_date('', $d)); ?></td>
          </tr>
        <?php endforeach; else: ?><tr><td colspan="3">No dependencies yet.</td></tr><?php endif; ?>
        </tbody>
      </table>
    </div>
    <?php
  }

  public static function render_settings(){
    if (! current_user_can('manage_options')) return;
    if ($_SERVER['REQUEST_METHOD']==='POST' && check_admin_referer('snow_settings')){
      $mode = isset($_POST['snow_mode']) && in_array($_POST['snow_mode'], array('intapp','external')) ? $_POST['snow_mode'] : 'intapp';
      update_option('snow_mode',$mode);
      echo '<div class="notice notice-success"><p>Settings saved.</p></div>';
    }
    $mode = get_option('snow_mode','intapp');
    ?>
    <div class="wrap snow-wrap"><h1>Settings</h1>
      <form method="post"><?php wp_nonce_field('snow_settings'); ?>
        <table class="form-table">
          <tr><th><label for="snow_mode">Operating Mode</label></th>
            <td><select name="snow_mode" id="snow_mode">
              <option value="intapp" <?php selected($mode,'intapp'); ?>>Intapp (Internal)</option>
              <option value="external" <?php selected($mode,'external'); ?>>External (Sanitized)</option>
            </select></td></tr>
        </table>
        <p><button class="button button-primary">Save</button></p>
      </form>
    </div>
    <?php
  }

  public static function render_export(){
    if (! current_user_can('manage_options')) return;
    $nonce = wp_create_nonce('snow_export_asana');
    $url = admin_url('admin-post.php?action=snow_export_asana&_wpnonce='.$nonce);
    echo '<div class="wrap snow-wrap"><h1>Export to Asana</h1><p><a class="button button-primary" href="'.esc_url($url).'">Download Asana CSV</a></p></div>';
  }
}

class SNOW_Admin_Helper {
  public static function marketer_metrics($marketer_id){
    $m = get_option('snow_marketer_cache_'.$marketer_id, array());
    $u = get_option('snow_upload_cache_org', array());
    $merged = array();
    if (!empty($m['data'])) $merged = array_merge($merged,$m['data']);
    if (!empty($u['data']) and is_array($u['data'])){ $merged['uploaded_rows'] = is_array($u['data']) ? count($u['data']) : 0; }
    return $merged;
  }
  public static function compute_top3($marketer_id){
    $metrics = self::marketer_metrics($marketer_id);
    $ideas = SNOW_Scorer::suggest_for_marketer($marketer_id,$metrics);
    return array_slice($ideas,0,3);
  }
  public static function compute_topN($marketer_id,$n){
    $metrics = self::marketer_metrics($marketer_id);
    $ideas = SNOW_Scorer::suggest_for_marketer($marketer_id,$metrics);
    return array_slice($ideas,0,$n);
  }
}
