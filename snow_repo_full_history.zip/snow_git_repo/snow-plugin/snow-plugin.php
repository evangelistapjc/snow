<?php
/**
 * Plugin Name: SNOW Plugin (CRO/A-B Ops Framework)
 * Description: Unified, role-inclusive CRO/A/B testing ops framework with per-marketer dashboards, scoring, integrations, and safe exports.
 * Version: 0.4.1
 * Author: Peej + Kai
 * License: GPL2
 * Text Domain: snow
 */

if ( ! defined( 'ABSPATH' ) ) { exit; }

define( 'SNOW_PLUGIN_VERSION', '0.4.1' );
define( 'SNOW_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SNOW_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

// Includes
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-cpt.php';
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-admin.php';
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-export.php';
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-sampledata.php';
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-scorer.php';
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-ingest.php';
require_once SNOW_PLUGIN_DIR . 'includes/class-snow-integrations.php';

class SNOW_Plugin {
    public function __construct() {
        add_action('init', array('SNOW_CPT', 'register'));
        add_action('admin_menu', array('SNOW_Admin', 'register_menu'));
        add_action('admin_enqueue_scripts', array('SNOW_Admin', 'enqueue_assets'));
        add_action('admin_post_snow_export_asana', array('SNOW_Export', 'handle_export'));
        register_activation_hook(__FILE__, array($this, 'on_activate'));
        register_deactivation_hook(__FILE__, array($this, 'on_deactivate'));
        load_plugin_textdomain('snow', false, dirname(plugin_basename(__FILE__)) . '/languages/');
    }
    public function on_activate() {
        SNOW_CPT::register();
        flush_rewrite_rules();
        if (! get_option('snow_mode')) add_option('snow_mode','intapp');
        SNOW_SampleData::seed();
    }
    public function on_deactivate() { flush_rewrite_rules(); }
}
new SNOW_Plugin();
