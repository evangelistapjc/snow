<?php
/**
 * Sample data seeder for Intapp Snow.
 *
 * Seeds a handful of marketers, teams and KPIs for demonstration purposes.  This
 * is invoked on plugin activation so you can immediately see the dashboard
 * populated with example content.  Feel free to remove or modify these seeds to
 * match your organisation.  Note that seeding is idempotent — existing posts
 * will not be duplicated.
 */
if ( ! defined( 'ABSPATH' ) ) { exit; }

class Intapp_Snow_SampleData {
    public static function seed() {
        $teams = array( 'Email', 'Web', 'CDA Sales', 'Paid Ads', 'Digital Marketing', 'Marketing Ops' );
        foreach ( $teams as $team ) {
            if ( ! term_exists( $team, 'intapp_team' ) ) {
                wp_insert_term( $team, 'intapp_team' );
            }
        }
        $profiles = array(
            array( 'name' => 'Elizabeth',   'team' => 'Email',            'kpis' => 'CTR, CTOR, CVR',                  'goals' => 'Increase nurture CTR; maintain deliverability' ),
            array( 'name' => 'Jenna',       'team' => 'Email',            'kpis' => 'Open Rate, CTR',                   'goals' => 'Lift open rate with subject testing' ),
            array( 'name' => 'Kelly',       'team' => 'Email',            'kpis' => 'Click-to-Open, CVR',               'goals' => 'Map clicks to LP CVR' ),
            array( 'name' => 'Gabe',        'team' => 'Web',              'kpis' => 'LCP, Bounce, CVR',                 'goals' => 'Improve LCP < 2.5s on key pages' ),
            array( 'name' => 'Colin',       'team' => 'Web',              'kpis' => 'Errors, Uptime, CVR',              'goals' => 'Zero critical errors in experiments' ),
            array( 'name' => 'Carlos',      'team' => 'Web',              'kpis' => 'Form CVR, Bugs',                   'goals' => 'Reduce form error rate by 20%' ),
            array( 'name' => 'Peej',        'team' => 'Web',              'kpis' => 'Sitewide CVR, Experiment Velocity', 'goals' => 'Ship two high‑ROI tests/mo' ),
            array( 'name' => 'Peyton',      'team' => 'CDA Sales',        'kpis' => 'MQL→SQL rate, Pipeline',           'goals' => 'Improve qualification consistency' ),
            array( 'name' => 'Kimberly',    'team' => 'CDA Sales',        'kpis' => 'Follow‑up time, SQL Rate',          'goals' => 'Tighten SLA compliance' ),
            array( 'name' => 'Peyton S',    'team' => 'CDA Sales',        'kpis' => 'MQL→SQL rate',                     'goals' => 'Enrich lead notes for quality' ),
            array( 'name' => 'Holly',       'team' => 'Paid Ads',         'kpis' => 'ROAS, CPL, CTR, CVR',               'goals' => 'LP CVR +12–18% while maintaining quality' ),
            array( 'name' => 'Denise',      'team' => 'Paid Ads',         'kpis' => 'CTR, CVR',                          'goals' => 'Persona‑aligned ad→LP messaging' ),
            array( 'name' => 'Rachel',      'team' => 'Digital Marketing','kpis' => 'Organic Sessions, CTR',             'goals' => 'SEO growth on strategic posts' ),
            array( 'name' => 'Roland',      'team' => 'Marketing Ops',    'kpis' => 'Experiment Velocity, Win Rate',      'goals' => 'Top‑5 tests always prioritised' ),
        );
        foreach ( $profiles as $p ) {
            $existing = get_page_by_title( $p['name'] . ' (' . $p['team'] . ')', OBJECT, 'intapp_marketer' );
            if ( ! $existing ) {
                $id = wp_insert_post( array(
                    'post_type'    => 'intapp_marketer',
                    'post_title'   => $p['name'] . ' (' . $p['team'] . ')',
                    'post_status'  => 'publish',
                    'post_content' => '[Placeholder profile for demo; not real metrics]',
                ) );
                if ( $id && ! is_wp_error( $id ) ) {
                    wp_set_post_terms( $id, array( $p['team'] ), 'intapp_team' );
                    update_post_meta( $id, 'snow_kpis', $p['kpis'] );
                    update_post_meta( $id, 'snow_goals', $p['goals'] );
                }
            }
        }
    }
}